package com.cart.audio.demo;

import static com.cart.audio.demo.R.raw.dengziqi_taohuanuo;
import static com.cart.audio.demo.R.raw.driver_notification;
import static com.cart.audio.demo.R.raw.free_flight;
import static com.cart.audio.demo.R.raw.huangxiaoyun_xingchendahai;
import static com.cart.audio.demo.R.raw.one2six;
import static com.cart.audio.demo.R.raw.opening_animation;
import static com.cart.audio.demo.R.raw.parking_guidance1;
import static com.cart.audio.demo.R.raw.parking_guidance2;
import static com.cart.audio.demo.R.raw.parking_guidance3;
import static com.cart.audio.demo.R.raw.parking_guidance4;
import static com.cart.audio.demo.R.raw.ring_classic_01;
import static com.cart.audio.demo.R.raw.safety_belt_warning;
import static com.cart.audio.demo.R.raw.testmp3_2;
import static com.cart.audio.demo.R.raw.turnlight;
import static com.cart.audio.demo.R.raw.turnright;
import static com.cart.audio.demo.R.raw.well_worth_the_wait;
import static com.cart.audio.demo.util.AudioUtils.getAudioLogTag;

import android.media.AudioAttributes;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.android.internal.widget.LinearLayoutManager;
import com.android.internal.widget.RecyclerView;
import com.cart.audio.demo.player.AudioPlayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AudioFocusTestFragment extends Fragment {

    public static final String FRAGMENT_NAME = "audio scene";
    private static final String TAG = getAudioLogTag(AudioFocusTestFragment.class);

    private final List<ScenePlayerItem> PLAYER_TYPES = new ArrayList<>(Arrays.asList(
            //MEDIA
            new ScenePlayerItem("Media1", AudioAttributes.USAGE_MEDIA, huangxiaoyun_xingchendahai),
            new ScenePlayerItem("Media2", AudioAttributes.USAGE_MEDIA, dengziqi_taohuanuo),
            //NAV
            new ScenePlayerItem("Nav1", AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE, one2six),
            new ScenePlayerItem("Nav2", AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE, turnright),
            //VOICE ASSISTANT
            new ScenePlayerItem("VR1", AudioAttributes.USAGE_ASSISTANT, parking_guidance1),
            new ScenePlayerItem("VR2", AudioAttributes.USAGE_ASSISTANT, parking_guidance2),
            //PHONE
            new ScenePlayerItem("Call Ring", AudioAttributes.USAGE_NOTIFICATION_RINGTONE, ring_classic_01),
            new ScenePlayerItem("Call", AudioAttributes.USAGE_VOICE_COMMUNICATION, well_worth_the_wait),
            //SYSTEM
            new ScenePlayerItem("alarm", AudioAttributes.USAGE_ALARM, testmp3_2),
            new ScenePlayerItem("System sound", AudioAttributes.USAGE_ASSISTANCE_SONIFICATION, free_flight),
            //SAFETY
            new ScenePlayerItem("PDC", AudioAttributes.USAGE_SAFETY, safety_belt_warning),
            new ScenePlayerItem("EXW", AudioAttributes.USAGE_SAFETY, driver_notification),
            new ScenePlayerItem("Turn Light", AudioAttributes.USAGE_SAFETY, turnlight),
            new ScenePlayerItem("Vehicle Status", AudioAttributes.USAGE_VEHICLE_STATUS, parking_guidance3),
            new ScenePlayerItem("Announcement", AudioAttributes.USAGE_ANNOUNCEMENT, opening_animation),
            new ScenePlayerItem("Emergency", AudioAttributes.USAGE_EMERGENCY, parking_guidance4)
    ));

    private final List<String> mAudioShowNames = new ArrayList<>(PLAYER_TYPES.size());
    private final List<AudioPlayer> mAudioPlayers = new ArrayList<>(PLAYER_TYPES.size());

    private RecyclerView mRecyclerView;

    private PlayerAdapter mPlayerAdapter;

    public AudioFocusTestFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.audio_player_tab, container, false);
        initPlayers();

        mRecyclerView = view.findViewById(R.id.players_view);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        mPlayerAdapter = new PlayerAdapter(mAudioShowNames, mAudioPlayers);
        mRecyclerView.setAdapter(mPlayerAdapter);
        mRecyclerView.scrollToPosition(0);

        return view;
    }

    @Override
    public void onDestroyView() {
        Log.i(TAG, "onDestroyView");
        for (AudioPlayer p : mAudioPlayers) {
            p.stop();
        }
        super.onDestroyView();
    }

    private void initPlayers() {
        for (int index = 0; index < PLAYER_TYPES.size(); index++) {
            ScenePlayerItem scene = PLAYER_TYPES.get(index);
            mAudioShowNames.add(scene.name);
            mAudioPlayers.add(getCarSoundsPlayer(scene.usage, scene.resourceId));
        }
    }

    private AudioPlayer getCarSoundsPlayer(int usage) {
        return getCarSoundsPlayer(usage, well_worth_the_wait);
    }

    private AudioPlayer getCarSoundsPlayer(int usage, int resourceId) {
        AudioAttributes.Builder builder = new AudioAttributes.Builder();
        if (AudioAttributes.isSystemUsage(usage)) {
            builder.setSystemUsage(usage);
        } else {
            builder.setUsage(usage);
        }
        AudioAttributes attributes = builder.build();
        if (getContext() == null) {
            Log.e(TAG, "getContext == null");
        } else {
            Log.d(TAG, "getContext is not null");
        }
        return new AudioPlayer(getContext(), resourceId, attributes);
    }

    class ScenePlayerItem {
        private String name;
        private int usage;
        private int resourceId;

        public ScenePlayerItem(String name, int usage, int resourceId) {
            this.name = name;
            this.usage = usage;
            this.resourceId = resourceId;
        }
    }
}
